package com.club.backend.clubManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClubManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClubManagerApplication.class, args);
	}

}
