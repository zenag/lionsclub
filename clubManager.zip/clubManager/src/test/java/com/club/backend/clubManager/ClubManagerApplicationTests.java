package com.club.backend.clubManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
